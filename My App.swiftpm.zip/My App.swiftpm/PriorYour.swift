import SwiftUI

@main
struct PriorYour: App {
    var body: some Scene {
        WindowGroup {
            // Present Starting Screen
           OpenScreen()
        }
    }
}
