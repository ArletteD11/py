import SwiftUI

struct OpenScreen: View {
    // Button for if Schedule is pressed
    @State private var schedulePressed = false
    
    var body: some View {
        NavigationView {
            VStack {
                // Logo/Home Screen
                Image("Logo")
                    .resizable()
                    .scaledToFit()
                    .edgesIgnoringSafeArea(.all)

                // Schedule Button
                Button(action: {
                    schedulePressed.toggle()
                }) {
                    Text("Schedule")
                        .font(.system(size: 25))
                        .padding()
                        .foregroundColor(.indigo)
                        .background(Color.teal)
                        .cornerRadius(15)
                        .shadow(color: .gray, radius: 3, x: 1, y: 1)
                }
                
                Image("AppName")
                    .resizable()
                    .scaledToFit()
                    .edgesIgnoringSafeArea(.all)
                    .frame(width: .infinity, height:75)
                .fullScreenCover(isPresented: $schedulePressed) {
                    ContentView()
                }
            }
            .background(Color.black)
        }
        .navigationViewStyle(StackNavigationViewStyle()) 
    }
}

